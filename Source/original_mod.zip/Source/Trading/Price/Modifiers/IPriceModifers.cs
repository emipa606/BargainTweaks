using System.Collections.Generic;
using RimWorld;

namespace BargainTweaks
{
    public interface IPriceModifiers
    {
        List<PriceModifier> Multipliers();
        List<PriceModifier> Bonuses();
    }
}