using HarmonyLib;
using System.Reflection;
using Verse;

namespace BargainTweaks
{
    [StaticConstructorOnStartup]
    static class BargainTweakHarmony
    {
        static BargainTweakHarmony()
        {
            Harmony harmony = new Harmony("sladki.rimworld.mod.bargainwweaks");
            harmony.PatchAll(Assembly.GetExecutingAssembly());
        }
    }
}