using System.Collections.Generic;
using RimWorld;
using UnityEngine;

namespace BargainTweaks
{
    public class EquilibriumModifier : IPriceModifiers
    {
        private readonly CombinedModifiers originModifiers;
        private readonly CombinedModifiers buyModifiers;
        private readonly CombinedModifiers sellModifiers;

        public EquilibriumModifier(
                IPriceModifiers originModifiers,
                IPriceModifiers buyModifiers,
                IPriceModifiers sellModifiers
        ) : this(
            new CombinedModifiers(originModifiers),
            new CombinedModifiers(buyModifiers),
            new CombinedModifiers(sellModifiers)
        )
        { }

        public EquilibriumModifier(
                CombinedModifiers originModifiers,
                CombinedModifiers buyModifiers,
                CombinedModifiers sellModifiers
        )
        {
            this.originModifiers = originModifiers;
            this.buyModifiers = buyModifiers;
            this.sellModifiers = sellModifiers;
        }

        public List<PriceModifier> Bonuses()
        {
            return WithEquilibriumBonus(originModifiers.Bonuses());
        }

        public List<PriceModifier> Multipliers()
        {
            return originModifiers.Multipliers();
        }

        private List<PriceModifier> WithEquilibriumBonus(List<PriceModifier> bonuses)
        {
            List<PriceModifier> result = bonuses;
            float buyMult = buyModifiers.CommonMultiplier();
            float sellMult = sellModifiers.CommonMultiplier();
            float bonusOfEqulibrium = (buyMult - sellMult) / (buyMult + sellMult);
            float bonus = 1f - originModifiers.CommonBonus();
            if(Mathf.Abs(bonus) > bonusOfEqulibrium)
            {
                result = new List<PriceModifier>();
                result.Add(BonusOfEquilibrium(bonusOfEqulibrium, -1f * (bonus / Mathf.Abs(bonus))));
            }
            return result;
        }

        private PriceModifier BonusOfEquilibrium(float bonusOfEqulibrium, float effectMult)
        {
            string bonusTitle = (bonusOfEqulibrium > 0) ? "BT_BonusCapped" : "BT_PriceCapped";
            return new PriceModifier(bonusTitle, bonusOfEqulibrium * effectMult);
        }
    }
}