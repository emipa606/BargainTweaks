namespace BargainTweaks
{
    public interface IBargainPrice
    {
        float Value();
        CombinedModifiers Modifiers();
    }
}