using RimWorld;
using Verse;

namespace BargainTweaks
{
    public class BasePriceTooltip
    {
        private readonly Tradeable item;
        private readonly IBargainPrice price;

        public BasePriceTooltip(Tradeable item, IBargainPrice price)
        {
            this.item = item;
            this.price = price;
        }

        public string Text()
        {
            string text = "\n\n" + BaseMarketValueText() + "\n";
            // Multipliers
            text = text + MultipliersText();
            // Bonuses
            text = text + BonusText() + "\n";
            // Final Price
            text = text + FinalPriceText();
            return text;
        }

        private string BaseMarketValueText()
        {
            return StatDefOf.MarketValue.LabelCap + ": " + item.BaseMarketValue.ToStringMoney("F2");
        }

        private string MultipliersText()
        {
            string text = string.Empty;
            foreach(PriceModifier pm in price.Modifiers().Multipliers())
            {
                if(pm.Value() != 1.0f)
                {
                    text = text
                            + " x "
                            + pm.Value().ToString("F2")
                            + " (" + pm.Name().Translate() + ")\n";
                }
            }
            return (text != string.Empty) ? text + "\n" : text;
        }

        private string BonusText()
        {
            string text = string.Empty;
            foreach(PriceModifier pm in price.Modifiers().Bonuses())
            {
                if(pm.Value() != 0.0f)
                {
                    text = text
                    + pm.Name().Translate()
                    + ": " + pm.Value().ToStringPercent() + "\n";
                }
            }
            return (text != string.Empty) ? text + "\n" : text;
        }

        private string FinalPriceText()
        {
            float p = price.Value();
            return "FinalPrice".Translate() + ": $" + ((p >= 100)
                    ? p.ToString()
                    : p.ToString("F2"));
        }
    }
}