using System.Reflection;
[assembly: AssemblyVersion("1.0.7.1")]