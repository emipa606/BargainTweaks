using RimWorld;
using UnityEngine;
using Verse;

namespace BargainTweaks
{
    public class TradeRowDemandHint
    {
        private readonly Rect rect;
        private readonly Tradeable item;
        private readonly TraderDemandRoll roll;

        public TradeRowDemandHint(Rect rect, Tradeable item) : this(
            rect,
            item,
            new TraderDemandRoll(item)
        )
        { }

        public TradeRowDemandHint(Rect rect, Tradeable item, TraderDemandRoll roll)
        {
            this.rect = rect;
            this.item = item;
            this.roll = roll;
        }

        public void Draw()
        {
            if(!item.IsCurrency && item.TraderWillTrade)
            {
                float rollValue = roll.Value();
                if(Mathf.Abs(rollValue) * BargainTweaks.settings.demandModifier > BargainTweaks.settings.demandHintThreshold)
                {
                    GUI.BeginGroup(rect);
                    DrawSellHint(rollValue);
                    DrawBuyHint(rollValue);
                    GUI.EndGroup();
                }
            }
        }

        private void DrawSellHint(float roll)
        {
            Rect hint = new Rect(rect.width - 410f, 5f, 5f, rect.height - 10f);
            Widgets.DrawBoxSolid(hint, Color(roll));
        }

        private void DrawBuyHint(float roll)
        {
            Rect hint = new Rect(rect.width - 185f, 5f, 5f, rect.height - 10f);
            Widgets.DrawBoxSolid(hint, Color(roll * -1f));
        }

        private Color Color(float roll)
        {
            float r = Mathf.Min(1f, 1f - roll);
            float g = Mathf.Min(1f, 1f + roll);
            return new Color(r, g, 0f);
        }
    }
}