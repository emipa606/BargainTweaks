namespace BargainTweaks
{
    public interface IPriceTooltip
    {
        string Text();
    }
}