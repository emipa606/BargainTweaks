using System.Collections.Generic;
using RimWorld;
using UnityEngine;

namespace BargainTweaks
{
    public class TraderDemandModifier : IPriceModifiers
    {
        private readonly Tradeable item;
        private readonly IPriceModifiers originModifiers;
        private readonly TraderDemandRoll roll;

        public TraderDemandModifier(Tradeable item, IPriceModifiers originModifiers) : this(
            item,
            originModifiers,
            new TraderDemandRoll(item)
        )
        { }

        public TraderDemandModifier(
            Tradeable item,
            IPriceModifiers originModifiers,
            TraderDemandRoll roll
        )
        {
            this.item = item;
            this.originModifiers = originModifiers;
            this.roll = roll;
        }

        private PriceModifier Mod(Tradeable item)
        {
            float rollValue = roll.Value();
            return new PriceModifier(
                    (rollValue > 0) ? "BT_DemandMod_High" : "BT_DemandMod_Low",
                    1f + PriceTypeMult(item) * BargainTweaks.settings.demandModifier * rollValue
            );
        }

        private float PriceTypeMult(Tradeable item)
        {
            float mult = 1f;
            if(BargainTweaks.settings.demandPriceTypeThreshold > 0f)
            {
                if(item.PriceTypeFor(RimWorld.TradeAction.PlayerBuys).PriceMultiplier() != 1f || item.PriceTypeFor(RimWorld.TradeAction.PlayerSells).PriceMultiplier() != 1f)
                {
                    float maxPriceType = Mathf.Max(
                        Mathf.Abs(1f - item.PriceTypeFor(RimWorld.TradeAction.PlayerBuys).PriceMultiplier()),
                        Mathf.Abs(1f - item.PriceTypeFor(RimWorld.TradeAction.PlayerSells).PriceMultiplier())
                    );
                    mult = Mathf.Max(0, 1f - (maxPriceType / BargainTweaks.settings.demandPriceTypeThreshold));
                }
            }
            return mult;
        }

        public List<PriceModifier> Multipliers()
        {
            List<PriceModifier> multipliers = originModifiers.Multipliers();
            multipliers.Add(Mod(item));
            return multipliers;
        }

        public List<PriceModifier> Bonuses()
        {
            return originModifiers.Bonuses();
        }
    }
}